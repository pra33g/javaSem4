https://www.codejava.net/java-ee/servlet/java-servlet-quick-start-tomcat-xml-config


Compile file using 

javac -cp TOMCAT_HOME/lib/server-api.jar -d WebContent/WEB-INF/classes src\net\codejava\servlet\QuickServlet.java

jar cfv deploy\QuickServletApp.war -C WebContent .

go to tomcat/bin and start tomcat.exe

go to localhost:8080/QuickServletApp